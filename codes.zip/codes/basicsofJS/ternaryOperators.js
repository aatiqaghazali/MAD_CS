let age=15;
let name= age > 16 ? 'aatiqa' : 'esha';
console.log(name)